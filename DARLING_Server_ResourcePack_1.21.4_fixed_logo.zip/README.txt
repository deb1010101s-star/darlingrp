DARLING Resource Pack for Minecraft Java 1.21.4

Optimized version:
- cropped extra transparent border from both glyph textures
- lowered ascent to reduce black artifact above the logo
- separate glyphs for scoreboard and TAB

Custom glyphs:
- Scoreboard: \uE000
- TAB: \uE001

Image sizes:
- sidebar_logo.png: 99x32
- tab_logo.png: 149x48
