DARLING Resource Pack for Minecraft Java 1.21.4

Version:
- pack_format: 46

Custom glyphs:
- Sidebar / scoreboard logo: U+E000  ->  -> 
- Tab logo:                  U+E001  ->  -> 

Files created:
- assets/minecraft/font/default.json
- assets/darling/textures/font/sidebar_logo.png  (107x36)
- assets/darling/textures/font/tab_logo.png      (157x52)

How to use on the server:
1) Put the ZIP on the server as the resource pack.
2) In your plugin/config, set the scoreboard title to the sidebar glyph.
3) In your tab plugin/config, set the header/footer to the tab glyph.

Examples:
- Scoreboard title: "\uE000"
- Tab header: "\uE001"

If your plugin does not support unicode escapes, copy the actual glyphs above directly.
